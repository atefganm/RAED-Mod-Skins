#!/bin/sh
#Created By RAED

SkinName=/usr/share/enigma2/MySkinHD/skin.xml

sed -i 's/name="bgbutton" value="#10161616"/name="bgbutton" value="#11000000"/g' $SkinName
sed -i 's/name="bgbutton2" value="#10161616"/name="bgbutton2" value="#10000000"/g' $SkinName
sed -i 's/name="bgbutton2" value="#1000365e"/name="bgbutton2" value="#10000000"/g' $SkinName

exit 0
